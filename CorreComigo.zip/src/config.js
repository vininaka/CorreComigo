export const firebaseConfig = {
    apiKey: "AIzaSyBIHWw0fs65P8z-MB4ZJDwIyAdyCKf_MO8",
    authDomain: "corre-comigo-33e9b.firebaseapp.com",
    databaseURL: "https://corre-comigo-33e9b.firebaseio.com",
    projectId: "corre-comigo-33e9b",
    storageBucket: "corre-comigo-33e9b.appspot.com",
    messagingSenderId: "71322330259",
    appId: "1:71322330259:web:a6b77fd9d632408e"
}
